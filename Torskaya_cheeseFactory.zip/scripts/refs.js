const documentRefs = {
    allGoods: document.querySelector('.allGoods'),
    cartIconCounter: document.querySelector('.carticon__counter'),
    cartIconBlock: document.querySelector('.carticon__showed'),
    prodListCart: document.querySelector('.cartOfAllGoods')
};

export default documentRefs;